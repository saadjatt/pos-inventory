<?php

$conn = mysqli_connect("localhost","root","","pos");
if (!$conn) {
	die("Connection failed: " . mysqli_connect_error());
}
 
?>